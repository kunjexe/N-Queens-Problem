# N-Queens Problem
 This is my pattern recoginition project for masters in which i going to use exhaustive search and genetic search algorithms. This whole project is based on python.
